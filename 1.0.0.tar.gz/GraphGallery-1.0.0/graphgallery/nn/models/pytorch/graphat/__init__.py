from .gcn_vat import GCN_VAT
from .graph_vat import GraphVAT