from .loss import BCELoss
from .autoencoder import AutoEncoder
from .gae import GAE
from .vgae import VGAE
