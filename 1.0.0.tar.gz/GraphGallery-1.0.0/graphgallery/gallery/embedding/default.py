import graphgallery as gg


def default_cfg_setup(cfg):
    # Base configs for model
    cfg.task = "Embedding"
